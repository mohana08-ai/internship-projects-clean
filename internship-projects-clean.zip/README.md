# Internship Projects

This repository contains two front-end projects built with HTML, CSS, and JavaScript.

## Projects
- **E-Commerce Website** – A basic multi-page store
- **Quiz Game** – A simple multiple-choice quiz

You can access both projects via the root `index.html` file.
